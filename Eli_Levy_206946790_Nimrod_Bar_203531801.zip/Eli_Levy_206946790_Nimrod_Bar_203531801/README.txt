C Homework project #3.

Creators: Eli Levy 206946790 And Nimrod Bar 203531801.

Known Errors: No errors found. 

Project gitHub HTTPS: https://github.com/Elilevy52/Introduction_to_systems_programming_HW3.git